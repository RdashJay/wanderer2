import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from './components/home';
import ExplorePage from './pages/explore';
import ItinerariesPage from './pages/itineraries';
import SavedPage from './pages/saved';
import ProfilePage from './pages/profile';
import DestinationPage from './pages/destination/[id]';
import SystemArchitecturePage from './pages/system-architecture';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/explore" element={<ExplorePage />} />
        <Route path="/itineraries" element={<ItinerariesPage />} />
        <Route path="/saved" element={<SavedPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/destination/:id" element={<DestinationPage />} />
        <Route path="/system-architecture" element={<SystemArchitecturePage />} />
      </Routes>
    </div>
  );
}

export default App;