import React from "react";
import { Card, CardContent } from "../ui/card";
import { ScrollArea, ScrollBar } from "../ui/scroll-area";
import { MapPin, Mountain, Utensils, Landmark, Compass } from "lucide-react";

interface CategoryProps {
  name: string;
  icon: React.ReactNode;
  description: string;
  color: string;
  onClick?: () => void;
}

const CategoryCard = ({
  name = "Nature",
  icon = <Mountain className="h-8 w-8" />,
  description = "Explore natural wonders",
  color = "bg-green-100",
  onClick = () => console.log(`Clicked on ${name}`),
}: CategoryProps) => {
  return (
    <Card
      className={`w-48 h-32 cursor-pointer hover:shadow-md transition-shadow ${color}`}
      onClick={onClick}
    >
      <CardContent className="flex flex-col items-center justify-center h-full p-4 text-center">
        <div className="mb-2">{icon}</div>
        <h3 className="font-semibold text-lg">{name}</h3>
        <p className="text-xs text-gray-600 mt-1">{description}</p>
      </CardContent>
    </Card>
  );
};

interface CategoryBrowserProps {
  categories?: CategoryProps[];
  onCategorySelect?: (category: string) => void;
}

const CategoryBrowser = ({
  categories = [
    {
      name: "Nature",
      icon: <Mountain className="h-8 w-8 text-green-600" />,
      description: "Explore natural wonders",
      color: "bg-green-100",
    },
    {
      name: "Culture",
      icon: <Landmark className="h-8 w-8 text-purple-600" />,
      description: "Discover local heritage",
      color: "bg-purple-100",
    },
    {
      name: "Adventure",
      icon: <Compass className="h-8 w-8 text-blue-600" />,
      description: "Thrilling activities",
      color: "bg-blue-100",
    },
    {
      name: "Food",
      icon: <Utensils className="h-8 w-8 text-orange-600" />,
      description: "Local cuisine & dining",
      color: "bg-orange-100",
    },
    {
      name: "Landmarks",
      icon: <MapPin className="h-8 w-8 text-red-600" />,
      description: "Must-visit locations",
      color: "bg-red-100",
    },
  ],
  onCategorySelect = (category) =>
    console.log(`Selected category: ${category}`),
}: CategoryBrowserProps) => {
  return (
    <div className="w-full bg-white p-4 shadow-sm">
      <h2 className="text-xl font-semibold mb-4">Explore Albay By Category</h2>
      <ScrollArea className="w-full">
        <div className="flex justify-center space-x-6 pb-4">
          {categories.map((category, index) => (
            <CategoryCard
              key={index}
              {...category}
              onClick={() => onCategorySelect(category.name)}
            />
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </div>
  );
};

export default CategoryBrowser;
