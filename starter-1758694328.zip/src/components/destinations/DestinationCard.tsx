import React from "react";
import { Card, CardContent, CardFooter, CardHeader } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Heart, MapPin, Star } from "lucide-react";
import { cn } from "@/lib/utils";

interface DestinationCardProps {
  id: string;
  name: string;
  image: string;
  description: string;
  category: string;
  rating: number;
  distance?: string;
  isSaved?: boolean;
  onSave?: (id: string) => void;
  onGetDirections?: (id: string) => void;
  onClick?: (id: string) => void;
}

const DestinationCard = ({
  id = "1",
  name = "Mayon Volcano",
  image = "https://images.unsplash.com/photo-1578950435899-d1c1bf932b6f?w=800&q=80",
  description = "Perfect cone-shaped active volcano, one of the Philippines' most iconic natural landmarks.",
  category = "Nature",
  rating = 4.8,
  distance = "12 km away",
  isSaved = false,
  onSave = () => {},
  onGetDirections = () => {},
  onClick = () => {},
}: DestinationCardProps) => {
  return (
    <Card className="w-full max-w-[300px] overflow-hidden transition-all duration-300 hover:shadow-lg bg-white">
      <div className="relative cursor-pointer" onClick={() => onClick(id)}>
        <div className="absolute top-2 right-2 z-10">
          <Button
            variant="ghost"
            size="icon"
            className="rounded-full bg-white/80 backdrop-blur-sm hover:bg-white/90"
            onClick={(e) => {
              e.stopPropagation();
              onSave(id);
            }}
          >
            <Heart
              className={cn(
                "h-5 w-5",
                isSaved ? "fill-red-500 text-red-500" : "text-gray-600",
              )}
            />
          </Button>
        </div>
        <div className="absolute top-2 left-2 z-10">
          <Badge
            variant="secondary"
            className="bg-white/80 backdrop-blur-sm text-gray-800"
          >
            {category}
          </Badge>
        </div>
        <div className="h-[180px] overflow-hidden">
          <img
            src={image}
            alt={name}
            className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
          />
        </div>
      </div>

      <CardHeader className="p-4 pb-2">
        <div className="flex justify-between items-start">
          <h3 className="text-lg font-semibold line-clamp-1">{name}</h3>
          <div className="flex items-center gap-1">
            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
            <span className="text-sm font-medium">{rating}</span>
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-4 pt-2 pb-3">
        <p className="text-sm text-gray-600 line-clamp-3">{description}</p>
        {distance && (
          <div className="flex items-center gap-1 mt-2 text-sm text-gray-500">
            <MapPin className="h-3.5 w-3.5" />
            <span>{distance}</span>
          </div>
        )}
      </CardContent>

      <CardFooter className="p-4 pt-0">
        <Button
          variant="default"
          className="w-full"
          onClick={(e) => {
            e.stopPropagation();
            onGetDirections(id);
          }}
        >
          Get Directions
        </Button>
      </CardFooter>
    </Card>
  );
};

export default DestinationCard;
