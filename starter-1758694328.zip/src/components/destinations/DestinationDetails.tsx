import React, { useState } from "react";
import { Button } from "../ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../ui/tabs";
import { Card } from "../ui/card";
import { Badge } from "../ui/badge";
import { Separator } from "../ui/separator";
import { ScrollArea } from "../ui/scroll-area";
import { Avatar } from "../ui/avatar";
import {
  Star,
  Clock,
  DollarSign,
  MapPin,
  Calendar,
  Heart,
  Share2,
  Navigation,
  Info,
} from "lucide-react";
import RouteOptions from "../navigation/RouteOptions";

interface Review {
  id: string;
  user: {
    name: string;
    avatar: string;
  };
  rating: number;
  date: string;
  comment: string;
}

interface Photo {
  id: string;
  url: string;
  alt: string;
}

interface DestinationDetailsProps {
  id?: string;
  name?: string;
  description?: string;
  category?: string;
  rating?: number;
  reviewCount?: number;
  address?: string;
  hours?: {
    days: string;
    time: string;
  }[];
  pricing?: {
    type: string;
    amount: number;
    currency: string;
  }[];
  photos?: Photo[];
  reviews?: Review[];
  latitude?: number;
  longitude?: number;
}

const DestinationDetails: React.FC<DestinationDetailsProps> = ({
  id = "mayon-volcano",
  name = "Mayon Volcano",
  description = "Mayon Volcano is an active stratovolcano in the province of Albay, known for its perfect cone shape. It's one of the Philippines' most iconic natural landmarks and a popular destination for hikers and nature enthusiasts.",
  category = "Nature",
  rating = 4.8,
  reviewCount = 245,
  address = "Albay Province, Bicol Region, Philippines",
  hours = [
    { days: "Monday - Sunday", time: "5:00 AM - 6:00 PM" },
    { days: "Guided Tours", time: "6:00 AM - 2:00 PM" },
  ],
  pricing = [
    { type: "Entrance Fee", amount: 100, currency: "PHP" },
    { type: "Guide Fee (required)", amount: 1500, currency: "PHP" },
    { type: "Environmental Fee", amount: 50, currency: "PHP" },
  ],
  photos = [
    {
      id: "1",
      url: "https://images.unsplash.com/photo-1577123613458-fee19974aaf1?w=800&q=80",
      alt: "Mayon Volcano perfect cone view",
    },
    {
      id: "2",
      url: "https://images.unsplash.com/photo-1584552541484-a5a0d0d3d301?w=800&q=80",
      alt: "Mayon Volcano with rice fields",
    },
    {
      id: "3",
      url: "https://images.unsplash.com/photo-1584552541484-a5a0d0d3d301?w=800&q=80",
      alt: "Mayon Volcano sunset view",
    },
    {
      id: "4",
      url: "https://images.unsplash.com/photo-1577123613458-fee19974aaf1?w=800&q=80",
      alt: "Mayon Volcano from Cagsawa ruins",
    },
  ],
  reviews = [
    {
      id: "1",
      user: {
        name: "Maria Santos",
        avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Maria",
      },
      rating: 5,
      date: "June 15, 2023",
      comment:
        "Absolutely breathtaking! The perfect cone shape is even more impressive in person. Make sure to book a guide in advance and start early to avoid the afternoon clouds.",
    },
    {
      id: "2",
      user: {
        name: "John Reyes",
        avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=John",
      },
      rating: 4,
      date: "May 3, 2023",
      comment:
        "Great experience hiking up to the viewpoint. The trail was well-maintained but quite challenging. The views were worth every step!",
    },
    {
      id: "3",
      user: {
        name: "Anna Lee",
        avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Anna",
      },
      rating: 5,
      date: "April 22, 2023",
      comment:
        "One of the most beautiful volcanoes I've ever seen. The local guides were very knowledgeable and friendly. Don't forget to bring a camera!",
    },
  ],
  latitude = 13.2543,
  longitude = 123.6858,
}) => {
  const [isSaved, setIsSaved] = useState(false);
  const [showRouteOptions, setShowRouteOptions] = useState(false);

  const renderStars = (rating: number) => {
    return Array(5)
      .fill(0)
      .map((_, i) => (
        <Star
          key={i}
          className={`h-4 w-4 ${i < Math.floor(rating) ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}`}
        />
      ));
  };

  return (
    <div className="bg-white w-full max-w-7xl mx-auto p-6 rounded-lg shadow-md">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-3xl font-bold text-gray-900">{name}</h1>
            <Badge className="bg-green-100 text-green-800 hover:bg-green-200">
              {category}
            </Badge>
          </div>
          <div className="flex items-center mt-2">
            <div className="flex mr-2">{renderStars(rating)}</div>
            <span className="text-gray-700">
              {rating} ({reviewCount} reviews)
            </span>
          </div>
          <div className="flex items-center mt-2 text-gray-600">
            <MapPin className="h-4 w-4 mr-1" />
            <span>{address}</span>
          </div>
        </div>
        <div className="flex gap-2 mt-4 md:mt-0">
          <Button
            variant="outline"
            className={`flex items-center gap-2 ${isSaved ? "text-red-500" : ""}`}
            onClick={() => setIsSaved(!isSaved)}
          >
            <Heart className={`h-4 w-4 ${isSaved ? "fill-red-500" : ""}`} />
            {isSaved ? "Saved" : "Save"}
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Share2 className="h-4 w-4" />
            Share
          </Button>
          <Button
            className="flex items-center gap-2"
            onClick={() => setShowRouteOptions(true)}
          >
            <Navigation className="h-4 w-4" />
            Get Directions
          </Button>
        </div>
      </div>

      {/* Photo Gallery */}
      <div className="mb-8">
        <div className="grid grid-cols-4 gap-2 h-80">
          <div className="col-span-2 row-span-2">
            <img
              src={photos[0].url}
              alt={photos[0].alt}
              className="w-full h-full object-cover rounded-l-lg"
            />
          </div>
          <div className="col-span-1">
            <img
              src={photos[1].url}
              alt={photos[1].alt}
              className="w-full h-full object-cover rounded-tr-lg"
            />
          </div>
          <div className="col-span-1">
            <img
              src={photos[2].url}
              alt={photos[2].alt}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="col-span-2">
            <img
              src={photos[3].url}
              alt={photos[3].alt}
              className="w-full h-full object-cover rounded-br-lg"
            />
          </div>
        </div>
      </div>

      {/* Tabs Section */}
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="w-full justify-start mb-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="hours">Hours & Pricing</TabsTrigger>
          <TabsTrigger value="reviews">Reviews</TabsTrigger>
          <TabsTrigger value="directions">Directions</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">About {name}</h2>
            <p className="text-gray-700 leading-relaxed">{description}</p>
            <div className="mt-6">
              <h3 className="text-lg font-medium mb-3">Highlights</h3>
              <ul className="list-disc pl-5 space-y-2 text-gray-700">
                <li>Perfect cone-shaped active volcano</li>
                <li>UNESCO World Heritage Site nominee</li>
                <li>Various hiking trails for different experience levels</li>
                <li>
                  Spectacular views of the Albay Gulf and surrounding landscape
                </li>
                <li>Rich biodiversity and unique ecosystem</li>
              </ul>
            </div>
            <div className="mt-6">
              <h3 className="text-lg font-medium mb-3">Tips for Visitors</h3>
              <ul className="list-disc pl-5 space-y-2 text-gray-700">
                <li>Best visited during the dry season (March to May)</li>
                <li>
                  Early morning visits offer clearer views before clouds form
                </li>
                <li>Hiring a local guide is mandatory for hiking activities</li>
                <li>
                  Bring sun protection, water, and appropriate hiking gear
                </li>
                <li>
                  Check volcanic activity alerts before planning your visit
                </li>
              </ul>
            </div>
          </Card>
        </TabsContent>

        {/* Hours & Pricing Tab */}
        <TabsContent value="hours" className="space-y-6">
          <Card className="p-6">
            <div className="mb-6">
              <h2 className="text-xl font-semibold mb-4">Opening Hours</h2>
              <div className="space-y-3">
                {hours.map((hour, index) => (
                  <div
                    key={index}
                    className="flex justify-between items-center"
                  >
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-2 text-gray-500" />
                      <span className="text-gray-700">{hour.days}</span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-2 text-gray-500" />
                      <span className="text-gray-700">{hour.time}</span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 p-3 bg-yellow-50 rounded-md border border-yellow-100">
                <div className="flex items-start">
                  <Info className="h-5 w-5 text-yellow-500 mr-2 mt-0.5" />
                  <p className="text-sm text-yellow-700">
                    Hours may vary during holidays or due to volcanic activity.
                    Always check current status before visiting.
                  </p>
                </div>
              </div>
            </div>

            <Separator className="my-6" />

            <div>
              <h2 className="text-xl font-semibold mb-4">Pricing</h2>
              <div className="space-y-3">
                {pricing.map((price, index) => (
                  <div
                    key={index}
                    className="flex justify-between items-center"
                  >
                    <div className="flex items-center">
                      <DollarSign className="h-4 w-4 mr-2 text-gray-500" />
                      <span className="text-gray-700">{price.type}</span>
                    </div>
                    <span className="font-medium">
                      {price.currency} {price.amount.toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>
              <div className="mt-6 p-4 bg-gray-50 rounded-md">
                <h3 className="text-md font-medium mb-2">
                  Additional Information
                </h3>
                <ul className="list-disc pl-5 space-y-1 text-sm text-gray-700">
                  <li>Children under 7 years old enter free</li>
                  <li>
                    Student and senior citizen discounts available with valid ID
                  </li>
                  <li>Group rates available for parties of 10 or more</li>
                  <li>Fees may change during peak season or special events</li>
                </ul>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Reviews Tab */}
        <TabsContent value="reviews" className="space-y-6">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold">Visitor Reviews</h2>
              <div className="flex items-center">
                <div className="flex mr-2">{renderStars(rating)}</div>
                <span className="text-gray-700">
                  {rating} ({reviewCount} reviews)
                </span>
              </div>
            </div>

            <ScrollArea className="h-[500px] pr-4">
              <div className="space-y-6">
                {reviews.map((review) => (
                  <div
                    key={review.id}
                    className="border-b border-gray-100 pb-6 last:border-0"
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex items-center">
                        <Avatar className="h-10 w-10 mr-3">
                          <img
                            src={review.user.avatar}
                            alt={review.user.name}
                          />
                        </Avatar>
                        <div>
                          <h4 className="font-medium">{review.user.name}</h4>
                          <div className="flex items-center mt-1">
                            <div className="flex mr-2">
                              {renderStars(review.rating)}
                            </div>
                            <span className="text-sm text-gray-500">
                              {review.date}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <p className="mt-3 text-gray-700">{review.comment}</p>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </Card>
        </TabsContent>

        {/* Directions Tab */}
        <TabsContent value="directions" className="space-y-6">
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Get Directions</h2>
            <div className="bg-gray-100 rounded-lg h-80 mb-6 flex items-center justify-center">
              {/* Placeholder for map */}
              <div className="text-center">
                <MapPin className="h-12 w-12 mx-auto text-gray-400" />
                <p className="mt-2 text-gray-600">Interactive map loading...</p>
                <p className="text-sm text-gray-500">
                  Coordinates: {latitude}, {longitude}
                </p>
              </div>
            </div>

            <Button
              className="w-full"
              onClick={() => setShowRouteOptions(true)}
            >
              <Navigation className="h-4 w-4 mr-2" />
              Plan Your Route
            </Button>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Route Options Dialog */}
      {showRouteOptions && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg w-full max-w-md p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Route Options to {name}</h2>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowRouteOptions(false)}
              >
                <span className="sr-only">Close</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </Button>
            </div>
            <RouteOptions destination={{ name, latitude, longitude }} />
          </div>
        </div>
      )}
    </div>
  );
};

export default DestinationDetails;
