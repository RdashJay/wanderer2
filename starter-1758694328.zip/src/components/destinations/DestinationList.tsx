import React, { useState } from "react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Filter, MapPin, Search } from "lucide-react";
import { Input } from "../ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";

interface Destination {
  id: string;
  name: string;
  description: string;
  image: string;
  category: string;
  rating: number;
  location: string;
}

interface DestinationListProps {
  destinations?: Destination[];
  title?: string;
  selectedCategory?: string;
  onDestinationClick?: (id: string) => void;
}

const DestinationList = ({
  destinations = [
    {
      id: "1",
      name: "Mayon Volcano",
      description:
        "Perfect cone-shaped active volcano, one of the Philippines most iconic landmarks.",
      image:
        "https://images.unsplash.com/photo-1577976793837-0eb37f6e1e93?w=800&q=80",
      category: "Nature",
      rating: 4.8,
      location: "Albay Province",
    },
    {
      id: "2",
      name: "Cagsawa Ruins",
      description:
        "Historic ruins of a 16th-century Franciscan church destroyed by the 1814 eruption.",
      image:
        "https://images.unsplash.com/photo-1582650625119-3a31f8fa2699?w=800&q=80",
      category: "Culture",
      rating: 4.5,
      location: "Daraga, Albay",
    },
    {
      id: "3",
      name: "Sumlang Lake",
      description:
        "Scenic lake with Mayon Volcano as backdrop, offering bamboo raft rides and local crafts.",
      image:
        "https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=800&q=80",
      category: "Nature",
      rating: 4.3,
      location: "Camalig, Albay",
    },
    {
      id: "4",
      name: "Lignon Hill Nature Park",
      description:
        "Panoramic viewpoint with zipline, hiking trails and 360-degree views of Albay Gulf and Mayon.",
      image:
        "https://images.unsplash.com/photo-1448375240586-882707db888b?w=800&q=80",
      category: "Adventure",
      rating: 4.4,
      location: "Legazpi City",
    },
    {
      id: "5",
      name: "Bicolano Food Tour",
      description:
        "Culinary adventure featuring spicy Bicol Express, Laing, and other local delicacies.",
      image:
        "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&q=80",
      category: "Food",
      rating: 4.7,
      location: "Various locations",
    },
    {
      id: "6",
      name: "Quitinday Green Hills",
      description:
        'Rolling hills formation often called the "Chocolate Hills of Albay".',
      image:
        "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80",
      category: "Nature",
      rating: 4.2,
      location: "Camalig, Albay",
    },
  ],
  title = "Popular Destinations",
  selectedCategory,
  onDestinationClick = () => {},
}: DestinationListProps) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");
  const [showFilters, setShowFilters] = useState(false);

  // Filter destinations based on search query and selected category/tab
  const filteredDestinations = destinations.filter((destination) => {
    const matchesSearch =
      destination.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      destination.description.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory =
      activeTab === "all" ||
      (selectedCategory && destination.category === selectedCategory) ||
      (!selectedCategory &&
        destination.category.toLowerCase() === activeTab.toLowerCase());

    return matchesSearch && matchesCategory;
  });

  return (
    <div className="w-full bg-white p-6 rounded-lg shadow-sm">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-4 md:mb-0">
          {title}
        </h2>

        <div className="flex flex-col sm:flex-row w-full md:w-auto gap-3">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search destinations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 w-full"
            />
          </div>

          <Button
            variant="outline"
            size="icon"
            onClick={() => setShowFilters(!showFilters)}
            className="h-10 w-10 sm:w-auto sm:px-4 flex items-center gap-2"
          >
            <Filter className="h-4 w-4" />
            <span className="hidden sm:inline">Filters</span>
          </Button>
        </div>
      </div>

      {showFilters && (
        <div className="mb-6 p-4 border rounded-lg bg-gray-50">
          <Tabs
            defaultValue="all"
            value={activeTab}
            onValueChange={setActiveTab}
          >
            <TabsList className="grid grid-cols-5 w-full max-w-3xl mx-auto">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="nature">Nature</TabsTrigger>
              <TabsTrigger value="culture">Culture</TabsTrigger>
              <TabsTrigger value="adventure">Adventure</TabsTrigger>
              <TabsTrigger value="food">Food</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      )}

      {filteredDestinations.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDestinations.map((destination) => (
            <Card key={destination.id} className="overflow-hidden">
              <div
                className="h-48 bg-cover bg-center"
                style={{ backgroundImage: `url(${destination.image})` }}
              />
              <div className="p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-semibold text-lg">
                      {destination.name}
                    </h3>
                    <div className="flex items-center text-sm text-gray-500 mt-1">
                      <MapPin className="h-3.5 w-3.5 mr-1" />
                      <span>{destination.location}</span>
                    </div>
                  </div>
                  <span className="bg-primary/10 text-primary text-xs px-2 py-1 rounded-full">
                    {destination.category}
                  </span>
                </div>
                <p className="text-gray-600 text-sm mt-3 line-clamp-2">
                  {destination.description}
                </p>
                <div className="flex justify-between items-center mt-4">
                  <div className="flex items-center">
                    <span className="text-amber-500">★</span>
                    <span className="ml-1 text-sm font-medium">
                      {destination.rating.toFixed(1)}
                    </span>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => onDestinationClick(destination.id)}
                  >
                    View Details
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <MapPin className="h-12 w-12 text-gray-300 mb-4" />
          <h3 className="text-xl font-medium text-gray-700">
            No destinations found
          </h3>
          <p className="text-gray-500 mt-2 max-w-md">
            Try adjusting your search or filter criteria to find more
            destinations.
          </p>
        </div>
      )}
    </div>
  );
};

export default DestinationList;
