import React from "react";
import { Card } from "../ui/card";

const SystemDFD = () => {
  return (
    <div className="p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-6 text-center">
        Wanderer App - Data Flow Diagram
      </h2>

      <div className="overflow-auto">
        <svg width="900" height="700" viewBox="0 0 900 700" className="mx-auto">
          {/* External Entities */}
          <rect
            x="50"
            y="50"
            width="120"
            height="60"
            rx="5"
            fill="#f0f9ff"
            stroke="#0369a1"
            strokeWidth="2"
          />
          <text
            x="110"
            y="85"
            textAnchor="middle"
            fontSize="14"
            fontWeight="bold"
          >
            User
          </text>

          <rect
            x="50"
            y="350"
            width="120"
            height="60"
            rx="5"
            fill="#f0f9ff"
            stroke="#0369a1"
            strokeWidth="2"
          />
          <text
            x="110"
            y="385"
            textAnchor="middle"
            fontSize="14"
            fontWeight="bold"
          >
            Map Service
          </text>

          <rect
            x="50"
            y="550"
            width="120"
            height="60"
            rx="5"
            fill="#f0f9ff"
            stroke="#0369a1"
            strokeWidth="2"
          />
          <text
            x="110"
            y="585"
            textAnchor="middle"
            fontSize="14"
            fontWeight="bold"
          >
            Location Data
          </text>

          {/* Main Processes */}
          <circle
            cx="300"
            cy="150"
            r="60"
            fill="#ecfdf5"
            stroke="#059669"
            strokeWidth="2"
          />
          <text
            x="300"
            y="150"
            textAnchor="middle"
            fontSize="14"
            fontWeight="bold"
          >
            1.0
          </text>
          <text x="300" y="170" textAnchor="middle" fontSize="14">
            User Interface
          </text>

          <circle
            cx="300"
            cy="350"
            r="60"
            fill="#ecfdf5"
            stroke="#059669"
            strokeWidth="2"
          />
          <text
            x="300"
            y="350"
            textAnchor="middle"
            fontSize="14"
            fontWeight="bold"
          >
            2.0
          </text>
          <text x="300" y="370" textAnchor="middle" fontSize="14">
            Map View
          </text>

          <circle
            cx="300"
            cy="550"
            r="60"
            fill="#ecfdf5"
            stroke="#059669"
            strokeWidth="2"
          />
          <text
            x="300"
            y="550"
            textAnchor="middle"
            fontSize="14"
            fontWeight="bold"
          >
            3.0
          </text>
          <text x="300" y="570" textAnchor="middle" fontSize="14">
            Destination Info
          </text>

          <circle
            cx="550"
            cy="250"
            r="60"
            fill="#ecfdf5"
            stroke="#059669"
            strokeWidth="2"
          />
          <text
            x="550"
            y="250"
            textAnchor="middle"
            fontSize="14"
            fontWeight="bold"
          >
            4.0
          </text>
          <text x="550" y="270" textAnchor="middle" fontSize="14">
            Category Filter
          </text>

          <circle
            cx="550"
            cy="450"
            r="60"
            fill="#ecfdf5"
            stroke="#059669"
            strokeWidth="2"
          />
          <text
            x="550"
            y="450"
            textAnchor="middle"
            fontSize="14"
            fontWeight="bold"
          >
            5.0
          </text>
          <text x="550" y="470" textAnchor="middle" fontSize="14">
            Itinerary Manager
          </text>

          {/* Data Stores */}
          <rect
            x="700"
            y="150"
            width="150"
            height="50"
            rx="0"
            fill="#eff6ff"
            stroke="#2563eb"
            strokeWidth="2"
          />
          <text
            x="775"
            y="180"
            textAnchor="middle"
            fontSize="14"
            fontWeight="bold"
          >
            D1: Destinations
          </text>

          <rect
            x="700"
            y="350"
            width="150"
            height="50"
            rx="0"
            fill="#eff6ff"
            stroke="#2563eb"
            strokeWidth="2"
          />
          <text
            x="775"
            y="380"
            textAnchor="middle"
            fontSize="14"
            fontWeight="bold"
          >
            D2: Categories
          </text>

          <rect
            x="700"
            y="550"
            width="150"
            height="50"
            rx="0"
            fill="#eff6ff"
            stroke="#2563eb"
            strokeWidth="2"
          />
          <text
            x="775"
            y="580"
            textAnchor="middle"
            fontSize="14"
            fontWeight="bold"
          >
            D3: Itineraries
          </text>

          {/* Arrows from User */}
          <line
            x1="170"
            y1="70"
            x2="240"
            y2="130"
            stroke="#000"
            strokeWidth="1.5"
            markerEnd="url(#arrowhead)"
          />
          <text x="190" y="90" textAnchor="middle" fontSize="12">
            Interactions
          </text>

          <line
            x1="170"
            y1="90"
            x2="240"
            y2="350"
            stroke="#000"
            strokeWidth="1.5"
            markerEnd="url(#arrowhead)"
          />
          <text x="190" y="200" textAnchor="middle" fontSize="12">
            Map Navigation
          </text>

          {/* Arrows between processes */}
          <line
            x1="300"
            y1="210"
            x2="300"
            y2="290"
            stroke="#000"
            strokeWidth="1.5"
            markerEnd="url(#arrowhead)"
          />
          <text x="320" y="250" textAnchor="middle" fontSize="12">
            Display Request
          </text>

          <line
            x1="300"
            y1="410"
            x2="300"
            y2="490"
            stroke="#000"
            strokeWidth="1.5"
            markerEnd="url(#arrowhead)"
          />
          <text x="320" y="450" textAnchor="middle" fontSize="12">
            Location Selection
          </text>

          <line
            x1="360"
            y1="150"
            x2="490"
            y2="230"
            stroke="#000"
            strokeWidth="1.5"
            markerEnd="url(#arrowhead)"
          />
          <text x="430" y="170" textAnchor="middle" fontSize="12">
            Filter Request
          </text>

          <line
            x1="360"
            y1="350"
            x2="490"
            y2="430"
            stroke="#000"
            strokeWidth="1.5"
            markerEnd="url(#arrowhead)"
          />
          <text x="430" y="370" textAnchor="middle" fontSize="12">
            Add to Itinerary
          </text>

          {/* Arrows to/from data stores */}
          <line
            x1="610"
            y1="250"
            x2="700"
            y2="180"
            stroke="#000"
            strokeWidth="1.5"
            markerEnd="url(#arrowhead)"
          />
          <text x="650" y="200" textAnchor="middle" fontSize="12">
            Query
          </text>

          <line
            x1="610"
            y1="250"
            x2="700"
            y2="350"
            stroke="#000"
            strokeWidth="1.5"
            markerEnd="url(#arrowhead)"
          />
          <text x="650" y="280" textAnchor="middle" fontSize="12">
            Filter By
          </text>

          <line
            x1="610"
            y1="450"
            x2="700"
            y2="550"
            stroke="#000"
            strokeWidth="1.5"
            markerEnd="url(#arrowhead)"
          />
          <text x="650" y="480" textAnchor="middle" fontSize="12">
            Save/Update
          </text>

          <line
            x1="700"
            y1="170"
            x2="360"
            y2="170"
            stroke="#000"
            strokeWidth="1.5"
            markerEnd="url(#arrowhead)"
          />
          <text x="530" y="150" textAnchor="middle" fontSize="12">
            Destination Data
          </text>

          <line
            x1="700"
            y1="370"
            x2="360"
            y2="370"
            stroke="#000"
            strokeWidth="1.5"
            markerEnd="url(#arrowhead)"
          />
          <text x="530" y="350" textAnchor="middle" fontSize="12">
            Category Data
          </text>

          <line
            x1="700"
            y1="560"
            x2="360"
            y2="560"
            stroke="#000"
            strokeWidth="1.5"
            markerEnd="url(#arrowhead)"
          />
          <text x="530" y="540" textAnchor="middle" fontSize="12">
            Itinerary Data
          </text>

          {/* Arrows to/from external entities */}
          <line
            x1="170"
            y1="350"
            x2="240"
            y2="350"
            stroke="#000"
            strokeWidth="1.5"
            markerEnd="url(#arrowhead)"
          />
          <text x="205" y="330" textAnchor="middle" fontSize="12">
            Map Data
          </text>

          <line
            x1="170"
            y1="550"
            x2="240"
            y2="550"
            stroke="#000"
            strokeWidth="1.5"
            markerEnd="url(#arrowhead)"
          />
          <text x="205" y="530" textAnchor="middle" fontSize="12">
            Location Info
          </text>

          <line
            x1="360"
            y1="550"
            x2="490"
            y2="480"
            stroke="#000"
            strokeWidth="1.5"
            markerEnd="url(#arrowhead)"
          />
          <text x="430" y="500" textAnchor="middle" fontSize="12">
            Destination Details
          </text>

          {/* Arrow definitions */}
          <defs>
            <marker
              id="arrowhead"
              markerWidth="10"
              markerHeight="7"
              refX="9"
              refY="3.5"
              orient="auto"
            >
              <polygon points="0 0, 10 3.5, 0 7" fill="#000" />
            </marker>
          </defs>
        </svg>
      </div>

      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h3 className="text-lg font-semibold mb-2">Processes</h3>
          <ul className="list-disc pl-5 space-y-1">
            <li>
              <span className="font-medium">1.0 User Interface:</span> Handles
              user interactions and display
            </li>
            <li>
              <span className="font-medium">2.0 Map View:</span> Manages map
              display and navigation
            </li>
            <li>
              <span className="font-medium">3.0 Destination Info:</span>{" "}
              Processes destination details
            </li>
            <li>
              <span className="font-medium">4.0 Category Filter:</span> Filters
              destinations by category
            </li>
            <li>
              <span className="font-medium">5.0 Itinerary Manager:</span>{" "}
              Manages user itineraries
            </li>
          </ul>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-2">Data Stores</h3>
          <ul className="list-disc pl-5 space-y-1">
            <li>
              <span className="font-medium">D1: Destinations:</span> Stores
              destination information
            </li>
            <li>
              <span className="font-medium">D2: Categories:</span> Stores
              category types and metadata
            </li>
            <li>
              <span className="font-medium">D3: Itineraries:</span> Stores
              user-created travel plans
            </li>
          </ul>
        </div>
      </div>

      <div className="mt-6">
        <h3 className="text-lg font-semibold mb-2">
          Technology Stack Recommendation
        </h3>
        <p className="mb-2">
          For this travel guidance system, the recommended technology stack is:
        </p>
        <ul className="list-disc pl-5 space-y-1">
          <li>
            <span className="font-medium">Frontend:</span> React with TypeScript
            (current implementation)
          </li>
          <li>
            <span className="font-medium">Backend:</span> Node.js with Express
            for API development
          </li>
          <li>
            <span className="font-medium">Database:</span> MongoDB for flexible
            document storage of travel data
          </li>
          <li>
            <span className="font-medium">Map Integration:</span> Mapbox or
            Google Maps API
          </li>
          <li>
            <span className="font-medium">State Management:</span> React Context
            API or Redux
          </li>
          <li>
            <span className="font-medium">Styling:</span> TailwindCSS (current
            implementation)
          </li>
          <li>
            <span className="font-medium">Authentication:</span> Firebase Auth
            or Auth0
          </li>
          <li>
            <span className="font-medium">Deployment:</span> Vercel or Netlify
            for frontend, Railway or Render for backend
          </li>
        </ul>
      </div>
    </div>
  );
};

export default SystemDFD;
