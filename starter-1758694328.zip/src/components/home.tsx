import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Header from "./layout/Header";
import MapView from "./map/MapView";
import CategoryBrowser from "./categories/CategoryBrowser";
import DestinationList from "./destinations/DestinationList";
import NotificationPanel from "./notifications/NotificationPanel";
import ItineraryPanel from "./itinerary/ItineraryPanel";
import { Button } from "./ui/button";
import { MapPin, Route, Calendar, Menu, Bell, Navigation } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "./ui/tooltip";

interface HomeProps {
  showNotifications?: boolean;
  showItinerary?: boolean;
}

const Home = ({
  showNotifications = false,
  showItinerary = false,
}: HomeProps) => {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [notificationsPanelOpen, setNotificationsPanelOpen] =
    useState(showNotifications);
  const [itineraryPanelOpen, setItineraryPanelOpen] = useState(showItinerary);
  const [selectedDestination, setSelectedDestination] = useState<string | null>(
    null,
  );

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
    console.log(`Selected category: ${category}`);
  };

  const handleDestinationClick = (id: string) => {
    setSelectedDestination(id);
    console.log(`Selected destination: ${id}`);
    // In a real implementation, this would navigate to the destination detail page
  };

  const handleAddToItinerary = (notification: any) => {
    setItineraryPanelOpen(true);
    console.log(`Added to itinerary: ${notification.title}`);
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header />

      <main className="flex-1">
        {/* Main Map View */}
        <MapView onMarkerClick={(id) => handleDestinationClick(id)} />

        {/* Category Browser */}
        <div className="container mx-auto px-4 -mt-10 relative z-10">
          <CategoryBrowser onCategorySelect={handleCategorySelect} />
        </div>

        {/* Popular Destinations */}
        <div className="container mx-auto px-4 py-8">
          <DestinationList
            selectedCategory={selectedCategory || undefined}
            onDestinationClick={handleDestinationClick}
          />
        </div>
      </main>

      {/* Fixed Action Buttons */}
      <div className="fixed bottom-6 right-6 flex flex-col gap-3">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                onClick={() => setItineraryPanelOpen(true)}
                className="rounded-full h-14 w-14 shadow-lg bg-white text-emerald-600 hover:bg-emerald-50 border border-emerald-200"
                variant="outline"
                size="icon"
              >
                <Calendar className="h-6 w-6" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="left">
              <p>View Itinerary</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>

        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                onClick={() => setNotificationsPanelOpen(true)}
                className="rounded-full h-14 w-14 shadow-lg bg-white text-emerald-600 hover:bg-emerald-50 border border-emerald-200"
                variant="outline"
                size="icon"
              >
                <Bell className="h-6 w-6" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="left">
              <p>Notifications</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>

        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                onClick={() => {
                  // Start navigation with current map view
                  console.log("Starting navigation");
                  // This would typically open the navigation interface
                  // For now, we'll just show a notification panel with route options
                  setNotificationsPanelOpen(true);
                }}
                className="rounded-full h-14 w-14 shadow-lg bg-emerald-600 text-white hover:bg-emerald-700"
                size="icon"
              >
                <Navigation className="h-6 w-6" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="left">
              <p>Start Navigation</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      {/* Panels */}
      <NotificationPanel
        isOpen={notificationsPanelOpen}
        onAddToItinerary={handleAddToItinerary}
      />

      <ItineraryPanel isOpen={itineraryPanelOpen} />
    </div>
  );
};

export default Home;
