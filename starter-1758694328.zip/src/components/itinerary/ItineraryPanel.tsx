import React, { useState } from "react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "../ui/sheet";
import { Button } from "../ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import {
  Calendar,
  Clock,
  MapPin,
  MoreHorizontal,
  Plus,
  Save,
  Trash2,
  ArrowUpDown,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../ui/dialog";

interface ItineraryItem {
  id: string;
  name: string;
  location: string;
  time: string;
  date: string;
  type: "attraction" | "restaurant" | "hotel" | "event";
}

interface ItineraryPanelProps {
  isOpen?: boolean;
  itineraries?: {
    id: string;
    name: string;
    items: ItineraryItem[];
  }[];
  onSave?: (itinerary: any) => void;
  onDelete?: (itineraryId: string) => void;
  onReorder?: (itineraryId: string, items: ItineraryItem[]) => void;
}

const ItineraryPanel = ({
  isOpen = false,
  itineraries = [
    {
      id: "itinerary-1",
      name: "Albay Adventure",
      items: [
        {
          id: "item-1",
          name: "Mayon Volcano National Park",
          location: "Legazpi City, Albay",
          time: "09:00 AM",
          date: "2023-06-15",
          type: "attraction",
        },
        {
          id: "item-2",
          name: "Lunch at Small Talk Café",
          location: "Legazpi Boulevard",
          time: "12:30 PM",
          date: "2023-06-15",
          type: "restaurant",
        },
        {
          id: "item-3",
          name: "Cagsawa Ruins",
          location: "Daraga, Albay",
          time: "02:00 PM",
          date: "2023-06-15",
          type: "attraction",
        },
      ],
    },
    {
      id: "itinerary-2",
      name: "Albay Food Tour",
      items: [
        {
          id: "item-4",
          name: "Breakfast at 1st Colonial Grill",
          location: "Legazpi City",
          time: "08:00 AM",
          date: "2023-06-16",
          type: "restaurant",
        },
        {
          id: "item-5",
          name: "Daraga Church Visit",
          location: "Daraga, Albay",
          time: "10:30 AM",
          date: "2023-06-16",
          type: "attraction",
        },
      ],
    },
  ],
  onSave = () => {},
  onDelete = () => {},
  onReorder = () => {},
}: ItineraryPanelProps) => {
  const [activeTab, setActiveTab] = useState("saved");
  const [selectedItinerary, setSelectedItinerary] = useState<string | null>(
    null,
  );
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editItem, setEditItem] = useState<ItineraryItem | null>(null);

  const handleEditItem = (item: ItineraryItem) => {
    setEditItem(item);
    setEditDialogOpen(true);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "attraction":
        return <MapPin className="h-4 w-4 text-blue-500" />;
      case "restaurant":
        return <MapPin className="h-4 w-4 text-orange-500" />;
      case "hotel":
        return <MapPin className="h-4 w-4 text-purple-500" />;
      case "event":
        return <MapPin className="h-4 w-4 text-green-500" />;
      default:
        return <MapPin className="h-4 w-4" />;
    }
  };

  // Update the open state when isOpen prop changes
  React.useEffect(() => {
    // No need to set state here as we're using the prop directly
  }, [isOpen]);

  return (
    <Sheet
      open={isOpen}
      onOpenChange={(open) => {
        // This would typically be handled by a parent component
        console.log("Itinerary panel", open ? "opened" : "closed");
      }}
    >
      <SheetContent className="w-[400px] sm:max-w-md bg-white" side="right">
        <SheetHeader>
          <SheetTitle className="text-xl font-bold">
            Your Itineraries
          </SheetTitle>
        </SheetHeader>

        <Tabs
          defaultValue="saved"
          className="mt-6"
          onValueChange={setActiveTab}
        >
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="saved">Saved Itineraries</TabsTrigger>
            <TabsTrigger value="current">Current Plan</TabsTrigger>
          </TabsList>

          <TabsContent value="saved" className="space-y-4 mt-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-medium">Your Saved Plans</h3>
              <Button
                size="sm"
                variant="outline"
                className="flex items-center gap-1"
              >
                <Plus className="h-4 w-4" />
                New Plan
              </Button>
            </div>

            <div className="space-y-3 mt-4">
              {itineraries.map((itinerary) => (
                <Card
                  key={itinerary.id}
                  className="cursor-pointer hover:bg-gray-50 transition-colors"
                >
                  <CardHeader className="p-4 pb-2">
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-base">
                        {itinerary.name}
                      </CardTitle>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="p-4 pt-0">
                    <p className="text-sm text-gray-500">
                      {itinerary.items.length} destinations
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-xs"
                        onClick={() => setSelectedItinerary(itinerary.id)}
                      >
                        View Details
                      </Button>
                      <Button size="sm" variant="ghost" className="text-xs">
                        <Trash2 className="h-3 w-3 mr-1" /> Delete
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="current" className="space-y-4 mt-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-medium">Current Plan</h3>
              <Button
                size="sm"
                variant="outline"
                className="flex items-center gap-1"
              >
                <Save className="h-4 w-4" />
                Save Plan
              </Button>
            </div>

            <div className="space-y-3 mt-4">
              {selectedItinerary && (
                <div className="space-y-3">
                  {itineraries
                    .find((i) => i.id === selectedItinerary)
                    ?.items.map((item) => (
                      <Card key={item.id} className="relative">
                        <CardContent className="p-4">
                          <div className="flex items-start gap-3">
                            <div className="mt-1">{getTypeIcon(item.type)}</div>
                            <div className="flex-1">
                              <h4 className="font-medium">{item.name}</h4>
                              <div className="flex items-center text-sm text-gray-500 mt-1">
                                <MapPin className="h-3 w-3 mr-1" />
                                {item.location}
                              </div>
                              <div className="flex items-center gap-3 mt-2">
                                <div className="flex items-center text-xs text-gray-500">
                                  <Calendar className="h-3 w-3 mr-1" />
                                  {item.date}
                                </div>
                                <div className="flex items-center text-xs text-gray-500">
                                  <Clock className="h-3 w-3 mr-1" />
                                  {item.time}
                                </div>
                              </div>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 absolute top-2 right-2"
                              onClick={() => handleEditItem(item)}
                            >
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  <div className="flex justify-between mt-4">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex items-center gap-1"
                    >
                      <ArrowUpDown className="h-3 w-3" />
                      Reorder
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex items-center gap-1"
                    >
                      <Plus className="h-3 w-3" />
                      Add Stop
                    </Button>
                  </div>
                </div>
              )}
              {!selectedItinerary && (
                <div className="text-center py-8">
                  <p className="text-gray-500 mb-4">No itinerary selected</p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex items-center gap-1 mx-auto"
                  >
                    <Plus className="h-3 w-3" />
                    Create New Plan
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>

        {/* Edit Item Dialog */}
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Itinerary Item</DialogTitle>
            </DialogHeader>
            {editItem && (
              <div className="space-y-4 py-4">
                <div className="grid w-full items-center gap-2">
                  <label className="text-sm font-medium">Name</label>
                  <input
                    type="text"
                    className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors"
                    defaultValue={editItem.name}
                  />
                </div>
                <div className="grid w-full items-center gap-2">
                  <label className="text-sm font-medium">Location</label>
                  <input
                    type="text"
                    className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors"
                    defaultValue={editItem.location}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid w-full items-center gap-2">
                    <label className="text-sm font-medium">Date</label>
                    <input
                      type="date"
                      className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors"
                      defaultValue={editItem.date}
                    />
                  </div>
                  <div className="grid w-full items-center gap-2">
                    <label className="text-sm font-medium">Time</label>
                    <input
                      type="time"
                      className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors"
                      defaultValue={editItem.time
                        .replace(" AM", "")
                        .replace(" PM", "")}
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2 mt-6">
                  <Button
                    variant="outline"
                    onClick={() => setEditDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button>Save Changes</Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </SheetContent>
    </Sheet>
  );
};

export default ItineraryPanel;
