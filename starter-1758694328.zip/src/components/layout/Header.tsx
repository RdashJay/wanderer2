import React from "react";
import { Button } from "../ui/button";

const Header = ({ title = "Wanderer", showNavigation = true }) => {
  return (
    <header className="bg-white shadow-sm border-b">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-blue-600">{title}</h1>
          {showNavigation && (
            <nav className="flex space-x-4">
              <Button variant="ghost">Home</Button>
              <Button variant="ghost">Explore</Button>
              <Button variant="ghost">Saved</Button>
              <Button variant="ghost">Profile</Button>
            </nav>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;