import React, { useState, useEffect } from "react";
import { Button } from "../ui/button";
import { Card } from "../ui/card";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "../ui/tooltip";
import {
  Layers,
  Navigation,
  Plus,
  Minus,
  MapPin,
  Info,
  Map,
  List,
} from "lucide-react";

interface MapViewProps {
  initialCenter?: { lat: number; lng: number };
  initialZoom?: number;
  markers?: Array<{
    id: string;
    position: { lat: number; lng: number };
    title: string;
    category: "nature" | "culture" | "adventure" | "food";
  }>;
  onMarkerClick?: (markerId: string) => void;
  showControls?: boolean;
}

const MapView = ({
  initialCenter = { lat: 13.1391, lng: 123.7438 }, // Default to Albay, Philippines
  initialZoom = 12,
  markers = [
    {
      id: "1",
      position: { lat: 13.1567, lng: 123.6982 },
      title: "Mayon Volcano",
      category: "nature",
    },
    {
      id: "2",
      position: { lat: 13.1391, lng: 123.7438 },
      title: "Cagsawa Ruins",
      category: "culture",
    },
    {
      id: "3",
      position: { lat: 13.1833, lng: 123.75 },
      title: "Sumlang Lake",
      category: "adventure",
    },
    {
      id: "4",
      position: { lat: 13.1422, lng: 123.7319 },
      title: "DJC Halo-Halo",
      category: "food",
    },
    {
      id: "5",
      position: { lat: 13.17, lng: 123.72 },
      title: "Lignon Hill",
      category: "nature",
    },
  ],
  onMarkerClick = () => {},
  showControls = true,
}: MapViewProps) => {
  const [zoom, setZoom] = useState(initialZoom + 2);
  const [center, setCenter] = useState(initialCenter);
  const [activeLayer, setActiveLayer] = useState("satellite");
  const [selectedMarkers, setSelectedMarkers] = useState<string[]>([]);

  // Mock function to simulate map interactions
  const handleZoomIn = () => {
    setZoom(Math.min(zoom + 1, 20));
  };

  const handleZoomOut = () => {
    setZoom(Math.max(zoom - 1, 1));
  };

  const handleLayerChange = (layer: string) => {
    setActiveLayer(layer);
  };

  const handleMarkerClick = (id: string) => {
    onMarkerClick(id);
    // Find the marker and center the map on it
    const marker = markers.find((m) => m.id === id);
    if (marker) {
      setCenter(marker.position);
    }
  };

  const toggleMarkerSelection = (category: string) => {
    const categoryMarkers = markers
      .filter((marker) => marker.category === category)
      .map((marker) => marker.id);

    if (categoryMarkers.every((id) => selectedMarkers.includes(id))) {
      // If all markers of this category are already selected, deselect them
      setSelectedMarkers(
        selectedMarkers.filter((id) => !categoryMarkers.includes(id)),
      );
    } else {
      // Otherwise, select all markers of this category
      setSelectedMarkers([
        ...new Set([...selectedMarkers, ...categoryMarkers]),
      ]);
    }
  };

  // Marker color based on category
  const getMarkerColor = (category: string) => {
    switch (category) {
      case "nature":
        return "bg-green-500";
      case "culture":
        return "bg-purple-500";
      case "adventure":
        return "bg-orange-500";
      case "food":
        return "bg-red-500";
      default:
        return "bg-blue-500";
    }
  };

  return (
    <div className="relative w-full h-[650px] bg-gray-100 overflow-hidden rounded-lg shadow-md">
      {/* Map Background - In a real implementation, this would be replaced with an actual map library */}
      <div
        className={`w-full h-full ${activeLayer === "satellite" ? "bg-[url(https://images.unsplash.com/photo-1569336415962-a4bd9f69c07b?w=1512&q=80)]" : "bg-[#e8f0f7]"} bg-cover bg-center`}
      >
        {/* Simulated Map Content */}
        <div className="absolute inset-0 flex items-center justify-center">
          {activeLayer === "standard" && (
            <div className="w-full h-full relative">
              {/* Simulated roads */}
              <div className="absolute top-1/2 left-0 right-0 h-1 bg-gray-300"></div>
              <div className="absolute top-0 bottom-0 left-1/2 w-1 bg-gray-300"></div>
              <div className="absolute top-1/4 left-1/4 right-0 h-0.5 bg-gray-300 transform -rotate-12"></div>
              <div className="absolute top-3/4 left-0 right-1/3 h-0.5 bg-gray-300 transform rotate-6"></div>

              {/* Simulated terrain */}
              <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-green-200 rounded-full opacity-40"></div>
              <div className="absolute bottom-1/3 right-1/4 w-48 h-48 bg-green-300 rounded-full opacity-30"></div>
              <div className="absolute top-1/3 right-1/3 w-24 h-24 bg-blue-200 rounded-full opacity-50"></div>
            </div>
          )}

          {/* Markers */}
          {markers.map((marker) => (
            <div
              key={marker.id}
              className={`absolute cursor-pointer transform -translate-x-1/2 -translate-y-1/2 transition-all duration-300 ${selectedMarkers.includes(marker.id) ? "scale-125" : "scale-100"}`}
              style={{
                top: `${50 - (marker.position.lat - center.lat) * 10}%`,
                left: `${50 + (marker.position.lng - center.lng) * 10}%`,
              }}
              onClick={() => handleMarkerClick(marker.id)}
            >
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className={`flex flex-col items-center`}>
                      <div
                        className={`w-6 h-6 ${getMarkerColor(marker.category)} rounded-full flex items-center justify-center text-white shadow-lg`}
                      >
                        <MapPin size={16} />
                      </div>
                      <div className="w-1 h-3 bg-black/50"></div>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="font-medium">{marker.title}</p>
                    <p className="text-xs capitalize">{marker.category}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          ))}
        </div>
      </div>

      {/* Map Controls */}
      {showControls && (
        <>
          {/* Zoom Controls */}
          <div className="absolute top-4 right-4 flex flex-col gap-2">
            <Button variant="secondary" size="icon" onClick={handleZoomIn}>
              <Plus size={18} />
            </Button>
            <Button variant="secondary" size="icon" onClick={handleZoomOut}>
              <Minus size={18} />
            </Button>
          </div>

          {/* Layer Controls */}
          <Card className="absolute top-4 left-4 p-2">
            <div className="flex flex-col gap-2">
              <Button
                variant={activeLayer === "standard" ? "default" : "outline"}
                size="sm"
                className="flex gap-2 items-center"
                onClick={() => handleLayerChange("standard")}
              >
                <Map size={16} />
                <span>Standard</span>
              </Button>
              <Button
                variant={activeLayer === "satellite" ? "default" : "outline"}
                size="sm"
                className="flex gap-2 items-center"
                onClick={() => handleLayerChange("satellite")}
              >
                <Layers size={16} />
                <span>Satellite</span>
              </Button>
            </div>
          </Card>

          {/* Category Filter */}
          <Card className="absolute bottom-4 left-4 p-2">
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                className={`bg-green-100 hover:bg-green-200 border-green-500 ${selectedMarkers.some((id) => markers.find((m) => m.id === id)?.category === "nature") ? "ring-2 ring-green-500" : ""}`}
                onClick={() => toggleMarkerSelection("nature")}
              >
                Nature
              </Button>
              <Button
                variant="outline"
                size="sm"
                className={`bg-purple-100 hover:bg-purple-200 border-purple-500 ${selectedMarkers.some((id) => markers.find((m) => m.id === id)?.category === "culture") ? "ring-2 ring-purple-500" : ""}`}
                onClick={() => toggleMarkerSelection("culture")}
              >
                Culture
              </Button>
              <Button
                variant="outline"
                size="sm"
                className={`bg-orange-100 hover:bg-orange-200 border-orange-500 ${selectedMarkers.some((id) => markers.find((m) => m.id === id)?.category === "adventure") ? "ring-2 ring-orange-500" : ""}`}
                onClick={() => toggleMarkerSelection("adventure")}
              >
                Adventure
              </Button>
              <Button
                variant="outline"
                size="sm"
                className={`bg-red-100 hover:bg-red-200 border-red-500 ${selectedMarkers.some((id) => markers.find((m) => m.id === id)?.category === "food") ? "ring-2 ring-red-500" : ""}`}
                onClick={() => toggleMarkerSelection("food")}
              >
                Food
              </Button>
            </div>
          </Card>

          {/* Info Panel */}
          <Card className="absolute bottom-4 right-4 p-3 flex items-center gap-2">
            <Info size={16} className="text-blue-500" />
            <span className="text-sm">
              Zoom: {zoom} | Center: {center.lat.toFixed(4)},{" "}
              {center.lng.toFixed(4)}
            </span>
          </Card>

          {/* Navigation Button */}
          <Button className="absolute bottom-20 right-4" variant="default">
            <Navigation className="mr-2 h-4 w-4" />
            Start Navigation
          </Button>
        </>
      )}
    </div>
  );
};

export default MapView;
