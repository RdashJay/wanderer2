import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Clock, MapPin, Route } from "lucide-react";

const RouteOptions = ({ destination = "Mayon Volcano" }) => {
  const routes = [
    {
      id: 1,
      name: "Fastest Route",
      duration: "45 mins",
      distance: "32 km",
      traffic: "Light",
      icon: <Route className="w-4 h-4" />
    },
    {
      id: 2,
      name: "Scenic Route",
      duration: "1h 15m",
      distance: "48 km", 
      traffic: "Moderate",
      icon: <MapPin className="w-4 h-4" />
    },
    {
      id: 3,
      name: "Avoid Traffic",
      duration: "52 mins",
      distance: "35 km",
      traffic: "Heavy",
      icon: <Clock className="w-4 h-4" />
    }
  ];

  return (
    <Card className="bg-white">
      <CardHeader>
        <CardTitle className="text-lg">Route Options to {destination}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {routes.map((route) => (
          <div key={route.id} className="p-3 border rounded-lg hover:bg-gray-50 cursor-pointer">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                {route.icon}
                <span className="font-medium">{route.name}</span>
              </div>
              <Button size="sm" variant="outline">Select</Button>
            </div>
            <div className="mt-2 text-sm text-gray-600 flex space-x-4">
              <span>{route.duration}</span>
              <span>{route.distance}</span>
              <span className={`${
                route.traffic === 'Light' ? 'text-green-600' :
                route.traffic === 'Moderate' ? 'text-yellow-600' : 'text-red-600'
              }`}>
                {route.traffic} traffic
              </span>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};

export default RouteOptions;