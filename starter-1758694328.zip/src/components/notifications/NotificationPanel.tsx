import React, { useState } from "react";
import { Bell, Calendar, Info, MapPin, X } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface NotificationItem {
  id: string;
  title: string;
  description: string;
  date: string;
  type: "event" | "festival" | "alert";
  location?: string;
  isNew?: boolean;
}

interface NotificationPanelProps {
  notifications?: NotificationItem[];
  onAddToItinerary?: (notification: NotificationItem) => void;
  onDismiss?: (id: string) => void;
  isOpen?: boolean;
}

const NotificationPanel = ({
  notifications = [
    {
      id: "1",
      title: "Mayon Volcano Festival",
      description:
        "Annual celebration featuring cultural performances, food fairs, and art exhibits.",
      date: "2023-06-15",
      type: "festival",
      location: "Legazpi City",
      isNew: true,
    },
    {
      id: "2",
      title: "Cagsawa Ruins Light Show",
      description:
        "Special evening light and sound show at the historic Cagsawa Ruins.",
      date: "2023-06-20",
      type: "event",
      location: "Daraga, Albay",
    },
    {
      id: "3",
      title: "Weather Alert: Heavy Rain",
      description:
        "Heavy rainfall expected in the Albay region. Some outdoor attractions may be temporarily closed.",
      date: "2023-06-10",
      type: "alert",
    },
    {
      id: "4",
      title: "Albay Farmers Market",
      description:
        "Special weekend market featuring local produce, crafts, and delicacies.",
      date: "2023-06-18",
      type: "event",
      location: "Tabaco City",
    },
    {
      id: "5",
      title: "Pili Nut Festival",
      description:
        "Celebration of Albay's famous pili nuts with cooking demonstrations and tastings.",
      date: "2023-06-25",
      type: "festival",
      location: "Ligao City",
      isNew: true,
    },
  ],
  onAddToItinerary = () => {},
  onDismiss = () => {},
  isOpen = false,
}: NotificationPanelProps) => {
  const [open, setOpen] = useState(isOpen);

  // Update the open state when isOpen prop changes
  React.useEffect(() => {
    setOpen(isOpen);
  }, [isOpen]);
  const [activeNotifications, setActiveNotifications] =
    useState<NotificationItem[]>(notifications);

  const handleDismiss = (id: string) => {
    setActiveNotifications(
      activeNotifications.filter((notification) => notification.id !== id),
    );
    onDismiss(id);
  };

  const handleAddToItinerary = (notification: NotificationItem) => {
    onAddToItinerary(notification);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "event":
        return <Calendar className="h-5 w-5 text-blue-500" />;
      case "festival":
        return <Calendar className="h-5 w-5 text-purple-500" />;
      case "alert":
        return <Info className="h-5 w-5 text-red-500" />;
      default:
        return <Bell className="h-5 w-5 text-gray-500" />;
    }
  };

  const getTypeBadge = (type: string) => {
    switch (type) {
      case "event":
        return (
          <Badge variant="secondary" className="bg-blue-100 text-blue-800">
            Event
          </Badge>
        );
      case "festival":
        return (
          <Badge variant="secondary" className="bg-purple-100 text-purple-800">
            Festival
          </Badge>
        );
      case "alert":
        return <Badge variant="destructive">Alert</Badge>;
      default:
        return <Badge>Notification</Badge>;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const newNotificationsCount = activeNotifications.filter(
    (notification) => notification.isNew,
  ).length;

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button
          variant="outline"
          className="relative p-2 h-10 w-10 rounded-full"
          onClick={() => setOpen(true)}
        >
          <Bell className="h-5 w-5" />
          {newNotificationsCount > 0 && (
            <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs text-white">
              {newNotificationsCount}
            </span>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-full sm:max-w-md bg-white">
        <SheetHeader>
          <SheetTitle className="text-xl font-bold">Notifications</SheetTitle>
        </SheetHeader>
        <div className="mt-6 flex flex-col space-y-4 overflow-y-auto max-h-[calc(100vh-120px)]">
          {activeNotifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 text-center">
              <Bell className="h-12 w-12 text-gray-300 mb-2" />
              <p className="text-gray-500">No notifications at this time</p>
            </div>
          ) : (
            activeNotifications.map((notification) => (
              <div
                key={notification.id}
                className={`relative rounded-lg border p-4 ${notification.isNew ? "bg-blue-50 border-blue-200" : "bg-white border-gray-200"}`}
              >
                <div className="flex justify-between items-start">
                  <div className="flex items-start space-x-3">
                    <div className="mt-0.5">
                      {getTypeIcon(notification.type)}
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <h3 className="font-medium text-gray-900">
                          {notification.title}
                        </h3>
                        {notification.isNew && (
                          <Badge
                            variant="secondary"
                            className="bg-blue-100 text-blue-800"
                          >
                            New
                          </Badge>
                        )}
                      </div>
                      <p className="mt-1 text-sm text-gray-600">
                        {notification.description}
                      </p>
                      <div className="mt-2 flex flex-wrap items-center gap-2">
                        {getTypeBadge(notification.type)}
                        <span className="text-xs text-gray-500">
                          {formatDate(notification.date)}
                        </span>
                        {notification.location && (
                          <div className="flex items-center text-xs text-gray-500">
                            <MapPin className="h-3 w-3 mr-1" />
                            {notification.location}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => handleDismiss(notification.id)}
                    className="text-gray-400 hover:text-gray-500"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
                {(notification.type === "event" ||
                  notification.type === "festival") && (
                  <div className="mt-3 pt-3 border-t border-gray-100">
                    <Button
                      onClick={() => handleAddToItinerary(notification)}
                      variant="outline"
                      size="sm"
                      className="w-full"
                    >
                      Add to Itinerary
                    </Button>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default NotificationPanel;
