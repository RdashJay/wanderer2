import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../components/layout/Header";
import CategoryBrowser from "../components/categories/CategoryBrowser";
import DestinationList from "../components/destinations/DestinationList";
import MapView from "../components/map/MapView";
import { Button } from "../components/ui/button";
import { Filter, Search } from "lucide-react";
import { Input } from "../components/ui/input";

const ExplorePage = () => {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [showMap, setShowMap] = useState(false);

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
    console.log(`Selected category: ${category}`);
  };

  const handleDestinationClick = (id: string) => {
    navigate(`/destination/${id}`);
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header />

      <main className="flex-1">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
            <h1 className="text-3xl font-bold text-gray-800">Explore Albay</h1>

            <div className="flex w-full md:w-auto gap-3">
              <div className="relative w-full md:w-64">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search destinations..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 w-full"
                />
              </div>

              <Button
                variant="outline"
                onClick={() => setShowMap(!showMap)}
                className="flex items-center gap-2"
              >
                {showMap ? "List View" : "Map View"}
              </Button>
            </div>
          </div>

          <CategoryBrowser onCategorySelect={handleCategorySelect} />

          {showMap ? (
            <div className="mt-6">
              <MapView onMarkerClick={(id) => handleDestinationClick(id)} />
            </div>
          ) : (
            <div className="mt-6">
              <DestinationList
                selectedCategory={selectedCategory || undefined}
                onDestinationClick={handleDestinationClick}
                title={
                  selectedCategory
                    ? `${selectedCategory} Destinations`
                    : "All Destinations"
                }
              />
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default ExplorePage;
