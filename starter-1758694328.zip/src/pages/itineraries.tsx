import React, { useState } from "react";
import Header from "../components/layout/Header";
import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "../components/ui/tabs";
import { Badge } from "../components/ui/badge";
import {
  Calendar,
  Clock,
  MapPin,
  Plus,
  ArrowUpDown,
  MoreHorizontal,
  Trash2,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../components/ui/dialog";

interface ItineraryItem {
  id: string;
  name: string;
  location: string;
  time: string;
  date: string;
  type: "attraction" | "restaurant" | "hotel" | "event";
}

interface Itinerary {
  id: string;
  name: string;
  description: string;
  startDate: string;
  endDate: string;
  items: ItineraryItem[];
}

const ItinerariesPage = () => {
  const [activeTab, setActiveTab] = useState("all");
  const [selectedItinerary, setSelectedItinerary] = useState<string | null>(
    null,
  );
  const [createDialogOpen, setCreateDialogOpen] = useState(false);

  // Mock itineraries data
  const itineraries: Itinerary[] = [
    {
      id: "itinerary-1",
      name: "Albay Adventure",
      description:
        "A 3-day exploration of Albay's natural wonders and cultural sites.",
      startDate: "2023-06-15",
      endDate: "2023-06-17",
      items: [
        {
          id: "item-1",
          name: "Mayon Volcano National Park",
          location: "Legazpi City, Albay",
          time: "09:00 AM",
          date: "2023-06-15",
          type: "attraction",
        },
        {
          id: "item-2",
          name: "Lunch at Small Talk Café",
          location: "Legazpi Boulevard",
          time: "12:30 PM",
          date: "2023-06-15",
          type: "restaurant",
        },
        {
          id: "item-3",
          name: "Cagsawa Ruins",
          location: "Daraga, Albay",
          time: "02:00 PM",
          date: "2023-06-15",
          type: "attraction",
        },
      ],
    },
    {
      id: "itinerary-2",
      name: "Albay Food Tour",
      description:
        "A culinary journey through Albay's best restaurants and food spots.",
      startDate: "2023-06-20",
      endDate: "2023-06-21",
      items: [
        {
          id: "item-4",
          name: "Breakfast at 1st Colonial Grill",
          location: "Legazpi City",
          time: "08:00 AM",
          date: "2023-06-20",
          type: "restaurant",
        },
        {
          id: "item-5",
          name: "Daraga Church Visit",
          location: "Daraga, Albay",
          time: "10:30 AM",
          date: "2023-06-20",
          type: "attraction",
        },
      ],
    },
    {
      id: "itinerary-3",
      name: "Weekend Getaway",
      description:
        "A relaxing weekend exploring the scenic spots around Albay.",
      startDate: "2023-07-01",
      endDate: "2023-07-02",
      items: [
        {
          id: "item-6",
          name: "Sumlang Lake",
          location: "Camalig, Albay",
          time: "09:30 AM",
          date: "2023-07-01",
          type: "attraction",
        },
        {
          id: "item-7",
          name: "Quitinday Green Hills",
          location: "Camalig, Albay",
          time: "01:00 PM",
          date: "2023-07-01",
          type: "attraction",
        },
      ],
    },
  ];

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "attraction":
        return <MapPin className="h-4 w-4 text-blue-500" />;
      case "restaurant":
        return <MapPin className="h-4 w-4 text-orange-500" />;
      case "hotel":
        return <MapPin className="h-4 w-4 text-purple-500" />;
      case "event":
        return <MapPin className="h-4 w-4 text-green-500" />;
      default:
        return <MapPin className="h-4 w-4" />;
    }
  };

  const formatDateRange = (startDate: string, endDate: string) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    return `${start.toLocaleDateString("en-US", { month: "short", day: "numeric" })} - ${end.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}`;
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header />

      <main className="flex-1">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold text-gray-800">My Itineraries</h1>
            <Button
              onClick={() => setCreateDialogOpen(true)}
              className="flex items-center gap-2"
            >
              <Plus className="h-4 w-4" />
              Create New Itinerary
            </Button>
          </div>

          <Tabs defaultValue="all" onValueChange={setActiveTab}>
            <TabsList className="w-full max-w-md mb-6">
              <TabsTrigger value="all">All Itineraries</TabsTrigger>
              <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
              <TabsTrigger value="past">Past</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {itineraries.map((itinerary) => (
                  <Card
                    key={itinerary.id}
                    className="hover:shadow-md transition-shadow"
                  >
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-xl">
                          {itinerary.name}
                        </CardTitle>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center text-sm text-gray-500 mb-2">
                        <Calendar className="h-4 w-4 mr-1" />
                        <span>
                          {formatDateRange(
                            itinerary.startDate,
                            itinerary.endDate,
                          )}
                        </span>
                      </div>
                      <p className="text-sm text-gray-700 mb-3">
                        {itinerary.description}
                      </p>
                      <div className="flex justify-between items-center">
                        <Badge variant="outline">
                          {itinerary.items.length} destinations
                        </Badge>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setSelectedItinerary(itinerary.id)}
                          >
                            View Details
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="upcoming">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {itineraries
                  .filter((i) => new Date(i.startDate) > new Date())
                  .map((itinerary) => (
                    <Card
                      key={itinerary.id}
                      className="hover:shadow-md transition-shadow"
                    >
                      <CardHeader className="pb-2">
                        <CardTitle className="text-xl">
                          {itinerary.name}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center text-sm text-gray-500 mb-2">
                          <Calendar className="h-4 w-4 mr-1" />
                          <span>
                            {formatDateRange(
                              itinerary.startDate,
                              itinerary.endDate,
                            )}
                          </span>
                        </div>
                        <p className="text-sm text-gray-700 mb-3">
                          {itinerary.description}
                        </p>
                        <Button size="sm" variant="outline" className="w-full">
                          View Details
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="past">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {itineraries
                  .filter((i) => new Date(i.endDate) < new Date())
                  .map((itinerary) => (
                    <Card
                      key={itinerary.id}
                      className="hover:shadow-md transition-shadow"
                    >
                      <CardHeader className="pb-2">
                        <CardTitle className="text-xl">
                          {itinerary.name}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center text-sm text-gray-500 mb-2">
                          <Calendar className="h-4 w-4 mr-1" />
                          <span>
                            {formatDateRange(
                              itinerary.startDate,
                              itinerary.endDate,
                            )}
                          </span>
                        </div>
                        <p className="text-sm text-gray-700 mb-3">
                          {itinerary.description}
                        </p>
                        <Button size="sm" variant="outline" className="w-full">
                          View Details
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </TabsContent>
          </Tabs>

          {selectedItinerary && (
            <div className="mt-10">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">
                  {itineraries.find((i) => i.id === selectedItinerary)?.name}{" "}
                  Details
                </h2>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex items-center gap-1"
                  >
                    <ArrowUpDown className="h-3 w-3" />
                    Reorder
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex items-center gap-1"
                  >
                    <Plus className="h-3 w-3" />
                    Add Stop
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                {itineraries
                  .find((i) => i.id === selectedItinerary)
                  ?.items.map((item) => (
                    <Card key={item.id} className="relative">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div className="mt-1">{getTypeIcon(item.type)}</div>
                          <div className="flex-1">
                            <h4 className="font-medium">{item.name}</h4>
                            <div className="flex items-center text-sm text-gray-500 mt-1">
                              <MapPin className="h-3 w-3 mr-1" />
                              {item.location}
                            </div>
                            <div className="flex items-center gap-3 mt-2">
                              <div className="flex items-center text-xs text-gray-500">
                                <Calendar className="h-3 w-3 mr-1" />
                                {item.date}
                              </div>
                              <div className="flex items-center text-xs text-gray-500">
                                <Clock className="h-3 w-3 mr-1" />
                                {item.time}
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                            >
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-red-500"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Create New Itinerary Dialog */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Create New Itinerary</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid w-full items-center gap-2">
              <label className="text-sm font-medium">Itinerary Name</label>
              <input
                type="text"
                placeholder="e.g., Weekend Adventure"
                className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors"
              />
            </div>
            <div className="grid w-full items-center gap-2">
              <label className="text-sm font-medium">Description</label>
              <textarea
                placeholder="Brief description of your itinerary"
                className="flex min-h-24 w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm transition-colors"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid w-full items-center gap-2">
                <label className="text-sm font-medium">Start Date</label>
                <input
                  type="date"
                  className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors"
                />
              </div>
              <div className="grid w-full items-center gap-2">
                <label className="text-sm font-medium">End Date</label>
                <input
                  type="date"
                  className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-6">
              <Button
                variant="outline"
                onClick={() => setCreateDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button>Create Itinerary</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ItinerariesPage;
