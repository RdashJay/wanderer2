import React from "react";
import Header from "../components/layout/Header";
import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "../components/ui/tabs";
import { Avatar } from "../components/ui/avatar";
import { Badge } from "../components/ui/badge";
import { Separator } from "../components/ui/separator";
import { Edit, MapPin, Calendar, Bookmark, Map, Settings } from "lucide-react";

const ProfilePage = () => {
  // Mock user data
  const user = {
    name: "Maria Santos",
    username: "mariasantos",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Maria",
    location: "Legazpi City, Albay",
    bio: "Travel enthusiast exploring the beautiful sights of Albay. Love hiking, photography, and local cuisine.",
    joinDate: "June 2023",
    stats: {
      visited: 24,
      reviews: 15,
      photos: 42,
      followers: 128,
      following: 87,
    },
    badges: [
      { name: "Explorer", description: "Visited 20+ destinations" },
      { name: "Photographer", description: "Uploaded 40+ photos" },
      { name: "Reviewer", description: "Posted 10+ reviews" },
    ],
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header />

      <main className="flex-1">
        <div className="container mx-auto px-4 py-6">
          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
                <Avatar className="h-24 w-24 border-4 border-white shadow-md">
                  <img src={user.avatar} alt={user.name} />
                </Avatar>

                <div className="flex-1 text-center md:text-left">
                  <div className="flex flex-col md:flex-row justify-between items-center mb-2">
                    <h1 className="text-2xl font-bold">{user.name}</h1>
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-2 md:mt-0 flex items-center gap-2"
                    >
                      <Edit className="h-4 w-4" />
                      Edit Profile
                    </Button>
                  </div>

                  <div className="flex items-center justify-center md:justify-start text-gray-600 mb-4">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span>{user.location}</span>
                    <span className="mx-2">•</span>
                    <Calendar className="h-4 w-4 mr-1" />
                    <span>Joined {user.joinDate}</span>
                  </div>

                  <p className="text-gray-700 mb-4">{user.bio}</p>

                  <div className="flex flex-wrap justify-center md:justify-start gap-4">
                    {user.badges.map((badge, index) => (
                      <Badge
                        key={index}
                        variant="secondary"
                        className="px-3 py-1"
                      >
                        {badge.name}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>

              <Separator className="my-6" />

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 text-center">
                <div>
                  <p className="text-2xl font-bold">{user.stats.visited}</p>
                  <p className="text-gray-600 text-sm">Places Visited</p>
                </div>
                <div>
                  <p className="text-2xl font-bold">{user.stats.reviews}</p>
                  <p className="text-gray-600 text-sm">Reviews</p>
                </div>
                <div>
                  <p className="text-2xl font-bold">{user.stats.photos}</p>
                  <p className="text-gray-600 text-sm">Photos</p>
                </div>
                <div>
                  <p className="text-2xl font-bold">{user.stats.followers}</p>
                  <p className="text-gray-600 text-sm">Followers</p>
                </div>
                <div>
                  <p className="text-2xl font-bold">{user.stats.following}</p>
                  <p className="text-gray-600 text-sm">Following</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="itineraries">
            <TabsList className="w-full justify-start mb-6">
              <TabsTrigger
                value="itineraries"
                className="flex items-center gap-2"
              >
                <Map className="h-4 w-4" />
                My Itineraries
              </TabsTrigger>
              <TabsTrigger value="saved" className="flex items-center gap-2">
                <Bookmark className="h-4 w-4" />
                Saved Places
              </TabsTrigger>
              <TabsTrigger value="settings" className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Account Settings
              </TabsTrigger>
            </TabsList>

            <TabsContent value="itineraries">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3].map((item) => (
                  <Card
                    key={item}
                    className="hover:shadow-md transition-shadow"
                  >
                    <CardHeader className="pb-2">
                      <CardTitle>Albay Adventure {item}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600 mb-3">
                        Created on June {item + 10}, 2023
                      </p>
                      <p className="text-sm mb-4">
                        A {item + 2}-day exploration of Albay's natural wonders
                        and cultural sites.
                      </p>
                      <div className="flex justify-between">
                        <Badge variant="outline">{item + 3} destinations</Badge>
                        <Button size="sm" variant="outline">
                          View
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="saved">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4].map((item) => (
                  <Card
                    key={item}
                    className="overflow-hidden hover:shadow-md transition-shadow"
                  >
                    <div className="h-40 bg-gray-200">
                      <img
                        src={`https://images.unsplash.com/photo-158${item}552541484-a5a0d0d3d301?w=600&q=80`}
                        alt="Saved place"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-semibold">
                        Saved Destination {item}
                      </h3>
                      <div className="flex items-center text-sm text-gray-500 mt-1">
                        <MapPin className="h-3.5 w-3.5 mr-1" />
                        <span>Albay, Philippines</span>
                      </div>
                      <div className="flex justify-between items-center mt-3">
                        <Badge
                          variant="secondary"
                          className="bg-blue-100 text-blue-800"
                        >
                          {item % 2 === 0 ? "Nature" : "Culture"}
                        </Badge>
                        <Button size="sm" variant="outline">
                          View
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="settings">
              <Card>
                <CardHeader>
                  <CardTitle>Account Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid w-full items-center gap-2">
                    <label className="text-sm font-medium">Display Name</label>
                    <input
                      type="text"
                      className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors"
                      defaultValue={user.name}
                    />
                  </div>
                  <div className="grid w-full items-center gap-2">
                    <label className="text-sm font-medium">Email</label>
                    <input
                      type="email"
                      className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors"
                      defaultValue="maria.santos@example.com"
                    />
                  </div>
                  <div className="grid w-full items-center gap-2">
                    <label className="text-sm font-medium">Location</label>
                    <input
                      type="text"
                      className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors"
                      defaultValue={user.location}
                    />
                  </div>
                  <div className="grid w-full items-center gap-2">
                    <label className="text-sm font-medium">Bio</label>
                    <textarea
                      className="flex min-h-24 w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm transition-colors"
                      defaultValue={user.bio}
                    />
                  </div>
                  <div className="flex justify-end">
                    <Button>Save Changes</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
};

export default ProfilePage;
