import React, { useState } from "react";
import Header from "../components/layout/Header";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "../components/ui/tabs";
import { Badge } from "../components/ui/badge";
import { Input } from "../components/ui/input";
import {
  MapPin,
  Search,
  Filter,
  Heart,
  Navigation,
  MoreHorizontal,
} from "lucide-react";

interface SavedPlace {
  id: string;
  name: string;
  description: string;
  image: string;
  category: string;
  location: string;
  distance?: string;
  rating: number;
  dateAdded: string;
}

const SavedPlacesPage = () => {
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  // Mock saved places data
  const savedPlaces: SavedPlace[] = [
    {
      id: "place-1",
      name: "Mayon Volcano",
      description:
        "Perfect cone-shaped active volcano, one of the Philippines' most iconic natural landmarks.",
      image:
        "https://images.unsplash.com/photo-1577123613458-fee19974aaf1?w=800&q=80",
      category: "Nature",
      location: "Albay Province",
      distance: "12 km away",
      rating: 4.8,
      dateAdded: "2023-05-15",
    },
    {
      id: "place-2",
      name: "Cagsawa Ruins",
      description:
        "Historic ruins of a 16th-century Franciscan church destroyed by the 1814 eruption.",
      image:
        "https://images.unsplash.com/photo-1582650625119-3a31f8fa2699?w=800&q=80",
      category: "Culture",
      location: "Daraga, Albay",
      distance: "8 km away",
      rating: 4.5,
      dateAdded: "2023-05-20",
    },
    {
      id: "place-3",
      name: "Sumlang Lake",
      description:
        "Scenic lake with Mayon Volcano as backdrop, offering bamboo raft rides and local crafts.",
      image:
        "https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=800&q=80",
      category: "Nature",
      location: "Camalig, Albay",
      distance: "15 km away",
      rating: 4.3,
      dateAdded: "2023-06-02",
    },
    {
      id: "place-4",
      name: "Lignon Hill Nature Park",
      description:
        "Panoramic viewpoint with zipline, hiking trails and 360-degree views of Albay Gulf and Mayon.",
      image:
        "https://images.unsplash.com/photo-1448375240586-882707db888b?w=800&q=80",
      category: "Adventure",
      location: "Legazpi City",
      distance: "5 km away",
      rating: 4.4,
      dateAdded: "2023-06-10",
    },
    {
      id: "place-5",
      name: "Bicolano Food Tour",
      description:
        "Culinary adventure featuring spicy Bicol Express, Laing, and other local delicacies.",
      image:
        "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&q=80",
      category: "Food",
      location: "Various locations",
      distance: "Varies",
      rating: 4.7,
      dateAdded: "2023-06-15",
    },
    {
      id: "place-6",
      name: "Quitinday Green Hills",
      description:
        'Rolling hills formation often called the "Chocolate Hills of Albay".',
      image:
        "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80",
      category: "Nature",
      location: "Camalig, Albay",
      distance: "20 km away",
      rating: 4.2,
      dateAdded: "2023-06-18",
    },
  ];

  // Filter saved places based on search query and selected category/tab
  const filteredPlaces = savedPlaces.filter((place) => {
    const matchesSearch =
      place.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      place.description.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory =
      activeTab === "all" ||
      (activeTab === "nature" && place.category === "Nature") ||
      (activeTab === "culture" && place.category === "Culture") ||
      (activeTab === "adventure" && place.category === "Adventure") ||
      (activeTab === "food" && place.category === "Food");

    return matchesSearch && matchesCategory;
  });

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header />

      <main className="flex-1">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <h1 className="text-3xl font-bold text-gray-800 mb-4 md:mb-0">
              Saved Places
            </h1>

            <div className="flex flex-col sm:flex-row w-full md:w-auto gap-3">
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search saved places..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 w-full"
                />
              </div>

              <Button
                variant="outline"
                size="icon"
                onClick={() => setShowFilters(!showFilters)}
                className="h-10 w-10 sm:w-auto sm:px-4 flex items-center gap-2"
              >
                <Filter className="h-4 w-4" />
                <span className="hidden sm:inline">Filters</span>
              </Button>
            </div>
          </div>

          {showFilters && (
            <div className="mb-6 p-4 border rounded-lg bg-gray-50">
              <Tabs
                defaultValue="all"
                value={activeTab}
                onValueChange={setActiveTab}
              >
                <TabsList className="grid grid-cols-5 w-full max-w-3xl mx-auto">
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="nature">Nature</TabsTrigger>
                  <TabsTrigger value="culture">Culture</TabsTrigger>
                  <TabsTrigger value="adventure">Adventure</TabsTrigger>
                  <TabsTrigger value="food">Food</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          )}

          {filteredPlaces.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredPlaces.map((place) => (
                <Card
                  key={place.id}
                  className="overflow-hidden hover:shadow-md transition-shadow"
                >
                  <div className="relative">
                    <div
                      className="h-48 bg-cover bg-center"
                      style={{ backgroundImage: `url(${place.image})` }}
                    />
                    <div className="absolute top-2 right-2 z-10">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="rounded-full bg-white/80 backdrop-blur-sm hover:bg-white/90"
                      >
                        <Heart className="h-5 w-5 fill-red-500 text-red-500" />
                      </Button>
                    </div>
                    <div className="absolute top-2 left-2 z-10">
                      <Badge
                        variant="secondary"
                        className="bg-white/80 backdrop-blur-sm text-gray-800"
                      >
                        {place.category}
                      </Badge>
                    </div>
                  </div>
                  <div className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold text-lg">{place.name}</h3>
                        <div className="flex items-center text-sm text-gray-500 mt-1">
                          <MapPin className="h-3.5 w-3.5 mr-1" />
                          <span>{place.location}</span>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </div>
                    <p className="text-gray-600 text-sm mt-3 line-clamp-2">
                      {place.description}
                    </p>
                    <div className="flex justify-between items-center mt-4">
                      <div className="flex items-center">
                        <span className="text-amber-500">★</span>
                        <span className="ml-1 text-sm font-medium">
                          {place.rating.toFixed(1)}
                        </span>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex items-center gap-1"
                        >
                          <Navigation className="h-3.5 w-3.5" />
                          Directions
                        </Button>
                        <Button size="sm">View</Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Heart className="h-12 w-12 text-gray-300 mb-4" />
              <h3 className="text-xl font-medium text-gray-700">
                No saved places found
              </h3>
              <p className="text-gray-500 mt-2 max-w-md">
                Try adjusting your search or filter criteria, or explore
                destinations to save some places.
              </p>
              <Button className="mt-6">Explore Destinations</Button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default SavedPlacesPage;
