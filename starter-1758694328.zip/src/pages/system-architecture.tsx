import React from "react";
import Header from "../components/layout/Header";
import SystemDFD from "../components/diagrams/SystemDFD";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "../components/ui/tabs";

const SystemArchitecturePage = () => {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header />

      <main className="flex-1">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold text-gray-800 mb-6">
            System Architecture
          </h1>

          <Tabs defaultValue="overview">
            <TabsList className="w-full max-w-md mb-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="dataflow">Data Flow</TabsTrigger>
              <TabsTrigger value="tech">Technology Stack</TabsTrigger>
            </TabsList>

            <TabsContent value="overview">
              <Card>
                <CardHeader>
                  <CardTitle>Wanderer: Smart Tourist Guide System</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="mb-4">
                    The Wanderer application is designed as a comprehensive
                    tourist guide for Albay, providing users with real-time
                    guidance and optimized routes to explore attractions
                    efficiently.
                  </p>

                  <h3 className="text-xl font-semibold mt-6 mb-3">
                    System Components
                  </h3>
                  <ul className="list-disc pl-5 space-y-2">
                    <li>
                      <span className="font-medium">User Interface Layer:</span>{" "}
                      React-based frontend with responsive design for mobile and
                      desktop access
                    </li>
                    <li>
                      <span className="font-medium">
                        Data Management Layer:
                      </span>{" "}
                      Handles destination data, user preferences, and
                      itineraries
                    </li>
                    <li>
                      <span className="font-medium">
                        Map Integration Layer:
                      </span>{" "}
                      Provides interactive mapping, location services, and route
                      optimization
                    </li>
                    <li>
                      <span className="font-medium">Notification System:</span>{" "}
                      Delivers event alerts and travel recommendations
                    </li>
                  </ul>

                  <h3 className="text-xl font-semibold mt-6 mb-3">
                    Key Features
                  </h3>
                  <ul className="list-disc pl-5 space-y-2">
                    <li>Interactive map interface with live directions</li>
                    <li>
                      Smart route optimization considering multiple factors
                    </li>
                    <li>Detailed location information pages</li>
                    <li>Category-based browsing of destinations</li>
                    <li>Event and festival notifications</li>
                    <li>Itinerary planning and management</li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="dataflow">
              <SystemDFD />
            </TabsContent>

            <TabsContent value="tech">
              <Card>
                <CardHeader>
                  <CardTitle>Technology Stack</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-3">
                        Frontend Technologies
                      </h3>
                      <ul className="list-disc pl-5 space-y-2">
                        <li>
                          <span className="font-medium">Framework:</span> React
                          with TypeScript
                        </li>
                        <li>
                          <span className="font-medium">Styling:</span>{" "}
                          TailwindCSS with Shadcn UI components
                        </li>
                        <li>
                          <span className="font-medium">Routing:</span> React
                          Router
                        </li>
                        <li>
                          <span className="font-medium">State Management:</span>{" "}
                          React Context API
                        </li>
                        <li>
                          <span className="font-medium">
                            Map Visualization:
                          </span>{" "}
                          Mapbox or Google Maps API
                        </li>
                        <li>
                          <span className="font-medium">Build Tool:</span> Vite
                        </li>
                      </ul>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold mb-3">
                        Backend Technologies
                      </h3>
                      <ul className="list-disc pl-5 space-y-2">
                        <li>
                          <span className="font-medium">Server:</span> Node.js
                          with Express
                        </li>
                        <li>
                          <span className="font-medium">Database:</span> MongoDB
                          for flexible document storage
                        </li>
                        <li>
                          <span className="font-medium">API:</span> RESTful API
                          architecture
                        </li>
                        <li>
                          <span className="font-medium">Authentication:</span>{" "}
                          JWT-based auth system
                        </li>
                        <li>
                          <span className="font-medium">
                            Geospatial Processing:
                          </span>{" "}
                          MongoDB geospatial queries
                        </li>
                        <li>
                          <span className="font-medium">Caching:</span> Redis
                          for performance optimization
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="mt-6">
                    <h3 className="text-lg font-semibold mb-3">
                      Development & Deployment
                    </h3>
                    <ul className="list-disc pl-5 space-y-2">
                      <li>
                        <span className="font-medium">Version Control:</span>{" "}
                        Git with GitHub
                      </li>
                      <li>
                        <span className="font-medium">CI/CD:</span> GitHub
                        Actions
                      </li>
                      <li>
                        <span className="font-medium">Frontend Hosting:</span>{" "}
                        Vercel or Netlify
                      </li>
                      <li>
                        <span className="font-medium">Backend Hosting:</span>{" "}
                        Railway or Render
                      </li>
                      <li>
                        <span className="font-medium">Monitoring:</span> Sentry
                        for error tracking
                      </li>
                      <li>
                        <span className="font-medium">Analytics:</span> Google
                        Analytics or Mixpanel
                      </li>
                    </ul>
                  </div>

                  <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <h3 className="text-lg font-semibold mb-2">
                      Recommended Programming Languages
                    </h3>
                    <p className="mb-3">
                      For this system, the following languages are recommended:
                    </p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>
                        <span className="font-medium">Frontend:</span>{" "}
                        TypeScript with React (current implementation)
                      </li>
                      <li>
                        <span className="font-medium">Backend:</span> TypeScript
                        with Node.js
                      </li>
                      <li>
                        <span className="font-medium">Database Queries:</span>{" "}
                        MongoDB Query Language
                      </li>
                      <li>
                        <span className="font-medium">DevOps:</span> YAML for
                        configuration, Bash for scripts
                      </li>
                    </ul>
                    <p className="mt-3 font-medium">
                      TypeScript is the best language choice for this system as
                      it provides:
                    </p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>Strong typing for complex travel data structures</li>
                      <li>
                        Better developer experience with autocomplete and error
                        detection
                      </li>
                      <li>Improved maintainability for a growing codebase</li>
                      <li>Consistency across frontend and backend</li>
                      <li>Enhanced documentation through type definitions</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
};

export default SystemArchitecturePage;
