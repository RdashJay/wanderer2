import SystemDFD from "@/components/diagrams/SystemDFD";

export default function SystemArchitectureStoryboard() {
  return (
    <div className="bg-gray-50 min-h-screen p-4">
      <SystemDFD />
    </div>
  );
}
