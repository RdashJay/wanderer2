import SystemDFD from "@/components/diagrams/SystemDFD";

const WandererDFDStoryboard = () => {
  return (
    <div className="p-4 bg-white rounded-lg shadow">
      <h2 className="text-2xl font-bold mb-4">
        Wanderer System Data Flow Diagram
      </h2>
      <SystemDFD />
    </div>
  );
};

export default WandererDFDStoryboard;