import SystemArchitecturePage from "../../../pages/system-architecture";

export default function SystemArchitectureStoryboard() {
  return (
    <div className="bg-white">
      <SystemArchitecturePage />
    </div>
  );
}
